# polyhorner
This package will:
- build univariate polynomials using an optimized Horner's method and fast numba loops
- build multivariate polynomials using a somewhat optimized Horner's method and fast numba loops


I use some functions distributed under the GNU LGPL license from 
https://people.sc.fsu.edu/~jburkardt/py_src/monomial
